
from umqtt.simple import MQTTClient
from machine import ADC, Pin
import network
import time
import machine
import dht
from machine import Timer



#wifi账号密码
SSID="SHELDON"
PASSWORD="33333204"
#阿里云mqtt服务器域名（改成自己的）
SERVER ='a1XoTTa0LDb.iot-as-mqtt.cn-shanghai.aliyuncs.com'
#三元组（找到mqtt工具上对应的改）
CLIENT_ID = "ESP|securemode=3,signmethod=hmacsha1,timestamp=789|"   
username='esp32&a1XoTTa0LDb'
password='2ed56c3f80a8198e84132b50e3e640308c641fd4'
#这个topic改成matt工具的属性上报那一行
publish_TOPIC = '/sys/a1XoTTa0LDb/esp32/thing/event/property/post'
subscribe_TOPIC ='/sys/a1XoTTa0LDb/esp32/thing/service/property/set'

client=None
mydht=None

def sub_cb(topic, msg):  
     print(msg)
    
     if msg == b'{"Led":1}':
       led.value(1)
     elif msg == b'{"Led":0}':
       led.value(0)
     elif msg == b'{"Beep":1}':
       beep.value(1)
     elif msg == b'{"Beep":0}':
       beep.value(0)
       
      
 
    
def ConnectWifi(ssid,passwd):   #连接wifi
    global wlan
    wlan=network.WLAN(network.STA_IF)         #create a wlan object
    wlan.active(True)                         #Activate the network interface
    wlan.disconnect()                         #Disconnect the last connected WiFi
    wlan.connect(ssid,passwd)                 #connect wifi
    while(wlan.ifconfig()[0]=='0.0.0.0'):
        time.sleep(1)
    print(wlan.ifconfig())
 
def apptimerevent(mytimer):
    try:
        wsData=ReadTemHum()
        Light=ReadLight()
        co2=ReadMQ()
        Led=led.value()
        Beep=beep.value()
        
        mymessage='{"params": {"Temp": %d ,"Hum": %d ,"Light": %d,"Led":%d,"Beep":%d,"co2":%d}, "method": "thing.event.property.post"}'%(wsData[0],wsData[1],Light,Led,Beep,co2)
        client.publish(topic=publish_TOPIC,msg= mymessage, retain=False, qos=0)
    except Exception as ex_results2:
        print('exception',ex_results2)
        mytimer.deinit()
        
def ReadTemHum():   #获取温湿度
    mydht.measure()
    tem=mydht.temperature()
    hum=mydht.humidity()
    data=[tem,hum]
    print(data)
    return data
    
def ReadLight():
   adcData=mylight.read()
   Lightvalu=10240000/(adcData*1.1)-2500 #adc转换
   Light=round(Lightvalu)  #取整
   print(Light)
   return Light
    
def ReadMQ():
   adcData2=mymq.read()
   co2valu=10240000/(adcData2*1.1)-1500 #adc转换
   co2=round(co2valu)  #取整
   print(co2)
   return co2
   
   
   
if __name__=='__main__':
    try:
      
        mydht=dht.DHT11(machine.Pin(21)) 
        
        mylight=ADC(machine.Pin(34))
        mymq=ADC(machine.Pin(35))
        led=Pin(1,Pin.OUT)
        beep=Pin(14,Pin.OUT)
        
        #pwm0 = PWM(Pin(26))  
        led.value(0)
        beep.value(0)
        
        #pwm0.freq(1000)      
        #pwm0.duty(200)       
        #pwm0.duty(int((0.5+0.1)/20*1023))
        #time.sleep_ms(10) 
        
        
        ConnectWifi(SSID,PASSWORD)
        client = MQTTClient(CLIENT_ID, SERVER,0,username,password,60)     #create a mqtt client
        print(client)
        
        client.set_callback(sub_cb)                         #set callback
        client.connect()                                    #connect mqtt
        client.subscribe(subscribe_TOPIC) 
        #client subscribes to a topic
        mytimer=Timer(0)
        mytimer.init(mode=Timer.PERIODIC, period=5000,callback=apptimerevent)   #初始化回调函数
        while True:
            client.wait_msg()  
            #wait message 
   
   
    except Exception  as ex_results:
        print('exception1',ex_results)
        
    finally:
        if(client is not None):
            client.disconnect()
        #wlan.disconnect()
        #wlan.active(False)





